import json
import os
import pandas as pd

ruta = r'users.json'
libraryId = []
Libros = []
Librerias = []



class Libreria:
    def __init__(self, libraryId, bookId,bookTitle,bookEditorial,bookPublication,userid,username):
        self.libraryId = libraryId
        self.bookId = bookId
        self.bookTitle = bookTitle
        self.bookEditorial = bookEditorial
        self.bookPublication = bookPublication
        self.userid = userid
        self.username = username

with open(ruta, 'r') as json_file:
    datos = json.load(json_file)
    for persona in datos:
        for libro in persona['books']:
            new_Libreria = Libreria(
                libro['libraryId'],
                libro['bookId'],
                libro['bookTitle'],
                libro['bookEditorial'],
                libro['bookPublication'],
                persona["userId"],
                persona["userName"]
            )
            Librerias.append(new_Libreria)

file_name = "libraries-and-book.json"
with open(file_name, 'w') as json_file:
    json.dump(Librerias, json_file, indent=2)

