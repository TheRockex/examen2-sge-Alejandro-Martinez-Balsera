import json
import os
import pandas as pd

ruta = r'users.json'
libraryId = []
Libros = []
Librerias = []



class Libreria:
    def __init__(self, bookId, libro):
        self.bookId = bookId
        self.libro = libro

with open(ruta, 'r') as json_file:
    datos = json.load(json_file)
    for persona in datos:
        for i in range(0, len(persona['books'])):
            if not libraryId.__contains__(persona['books'][i]['libraryId']):
                libraryId.append(persona['books'][i]['libraryId'])
                Libros.append(persona['books'])

print(libraryId)
for  libros in Libros:
    for libro in libros:
        if libro['libraryId'] == libraryId[0]:
            new_Libreria = Libreria(
                libraryId[0],
                Libros[i],
            )
            print(new_Libreria)
            Librerias.append(new_Libreria)
        elif libro['libraryId'] == libraryId[1]:
            new_Libreria = Libreria(
                libraryId[1],
                Libros[i],
            )
            Librerias.append(new_Libreria)
        elif libro['libraryId'] == libraryId[2]:
            new_Libreria = Libreria(
                libraryId[2],
                Libros[i],
            )
            Librerias.append(new_Libreria)
        elif libro['libraryId'] == libraryId[3]:
            new_Libreria = Libreria(
                libraryId[3],
                Libros[i],
            )
            Librerias.append(new_Libreria)
        elif libro['libraryId'] == libraryId[4]:
            new_Libreria = Libreria(
                libraryId[4],
                Libros[i],
            )
            Librerias.append(new_Libreria)

print(new_Libreria)

file_name = "secure-users.json"

with open(file_name, 'w') as json_file:
    json.dumps(['Libreria', {'ID': Librerias.__getattribute__('bookId')}])