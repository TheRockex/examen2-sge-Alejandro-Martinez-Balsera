import json
import os
import hashlib

ruta = r'users.json'
userId = []
userName = []
userSurname = []
password = []
books = []

def hash_password(contra):
    sha256 = hashlib.sha256()
    contraB = contra.encode('utf-8')
    sha256.update(contraB)
    contraHas = sha256.hexdigest()
    return contraHas


with open(ruta, 'r') as json_file:
    datos = json.load(json_file)
    for persona in datos:
        persona['password'] = hash_password( persona['password'])

file_name = "secure-users.json"

with open(file_name, 'w') as json_file:
    json.dump(datos, json_file, indent=2)