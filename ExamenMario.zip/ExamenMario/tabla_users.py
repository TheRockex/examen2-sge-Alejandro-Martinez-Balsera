import json
import os
import pandas as pd

ruta = r'secure-users.json'
userId = []
userName = []
userSurname = []
password = []
books = []

with open(ruta, 'r') as json_file:
    datos = json.load(json_file)
    for persona in datos:
        userId.append(persona['userId'])
        userName.append(persona['userName'])
        userSurname.append(persona['userSurname'])
        password.append(persona['password'])

df = pd.DataFrame({'ID': userId, 'Nombre': userName, 'Apellido': userSurname, 'Contraseña': password})
df.to_excel(f'usuarios.xlsx')

